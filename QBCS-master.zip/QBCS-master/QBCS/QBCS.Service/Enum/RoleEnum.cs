﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.Enum
{
    public enum RoleEnum
    {
        Admin = 1,
        Lecturer = 2,
        Staff = 3
    }
}
