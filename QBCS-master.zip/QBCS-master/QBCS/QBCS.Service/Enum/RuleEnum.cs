﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.Enum
{
    public enum RuleEnum
    {
        Question = 1,
        Option = 2,
        Correct_Option = 3,
        Incorrect_Option = 4
    }
}
