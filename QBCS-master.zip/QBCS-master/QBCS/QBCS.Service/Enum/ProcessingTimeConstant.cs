﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.Enum
{
    public class ProcessingTimeConstant
    {
        public static readonly float NO_SEMANTIC = 1f;
        public static readonly float SEMANTIC = 330f;
    }
}
