﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.Enum
{
    public enum LogEnum
    {
        Import,
        Cancel,
        Save,
        Update,
        Move
    }
}
