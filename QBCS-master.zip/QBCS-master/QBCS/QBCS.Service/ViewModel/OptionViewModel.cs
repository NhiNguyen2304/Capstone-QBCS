﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.ViewModel
{
    public class OptionViewModel
    {
        public int Id { get; set; }
        public string OptionContent { get; set; }
        public bool IsCorrect { get; set; }
        public string Image { get; set; }
        public List<ImageViewModel> Images { get; set; }
    }
}
