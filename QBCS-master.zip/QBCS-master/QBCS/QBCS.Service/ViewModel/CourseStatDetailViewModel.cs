﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.ViewModel
{
    public class CourseStatDetailViewModel
    {
        public string Type { get; set; }
        public string Name { get; set; }
        public int Null { get; set; }
        public int Easy { get; set; }
        public int Medium { get; set; }
        public int Hard { get; set; }
        public List<string> Suggestion { get; set; }
    }
}
