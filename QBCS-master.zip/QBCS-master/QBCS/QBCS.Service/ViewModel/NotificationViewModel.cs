﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.ViewModel
{
    public class NotificationViewModel
    {
        public int ImportId { get; set; }
        public string Message { get; set; }
        public int Status { get; set; }
        public string UpdatedDate { get; set; }
    }
}
