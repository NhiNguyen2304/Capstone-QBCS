﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Service.ViewModel
{
    public class RuleAjaxHandleViewModel
    {
        public int KeyId { get; set; }
        public string Value { get; set; }
        public DateTime ActivateDate { get; set; }
        public bool IsUse { get; set; }

    }
}
