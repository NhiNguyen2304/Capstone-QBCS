﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QBCS.Repository.ViewModel
{
    public class ExaminationChartViewModel
    {
        public int TotalQuestions { get; set; }
        public string GroupExam { get; set; }
        public int TotalDuplicate { get; set; }
    }
}
